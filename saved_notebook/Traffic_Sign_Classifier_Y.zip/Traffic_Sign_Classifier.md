
# Self-Driving Car Engineer Nanodegree

## Deep Learning

## Project: Build a Traffic Sign Recognition Classifier

In this notebook, a template is provided for you to implement your functionality in stages, which is required to successfully complete this project. If additional code is required that cannot be included in the notebook, be sure that the Python code is successfully imported and included in your submission if necessary. 

> **Note**: Once you have completed all of the code implementations, you need to finalize your work by exporting the iPython Notebook as an HTML document. Before exporting the notebook to html, all of the code cells need to have been run so that reviewers can see the final implementation and output. You can then export the notebook by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission. 

In addition to implementing code, there is a writeup to complete. The writeup should be completed in a separate file, which can be either a markdown file or a pdf document. There is a [write up template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) that can be used to guide the writing process. Completing the code template and writeup template will cover all of the [rubric points](https://review.udacity.com/#!/rubrics/481/view) for this project.

The [rubric](https://review.udacity.com/#!/rubrics/481/view) contains "Stand Out Suggestions" for enhancing the project beyond the minimum requirements. The stand out suggestions are optional. If you decide to pursue the "stand out suggestions", you can include the code in this Ipython notebook and also discuss the results in the writeup file.


>**Note:** Code and Markdown cells can be executed using the **Shift + Enter** keyboard shortcut. In addition, Markdown cells can be edited by typically double-clicking the cell to enter edit mode.

---
## Step 0: Load The Data


```python
### Additional imports
import numpy as np
import cv2
import matplotlib.image as mpimg
from random import randint
import csv
```


```python
### Constants

### Preprocessing the images
DO_GRAYSCALE=False
DO_NORMALIZE=False
DO_STANDARDIZATION=True
DO_BGR2YUV=True
DO_YUV2GRAYSCALE=True

### Image augmentation
DO_CHANGE_BRIGHTNESS=True
DO_CROP=True
DO_ROTATE=True
DO_PAD=True

### TensorFlow training
EPOCHS = 30
BATCH_SIZE = 256
```


```python
# Load pickled data
import pickle

# Load training, valid and testing data

training_file = "data/train.p"
validation_file= "data/valid.p"
testing_file = "data/test.p"

with open(training_file, mode='rb') as f:
    train = pickle.load(f)
with open(validation_file, mode='rb') as f:
    valid = pickle.load(f)
with open(testing_file, mode='rb') as f:
    test = pickle.load(f)
    
X_train_org, y_train_org = train['features'], train['labels']
X_valid_org, y_valid_org = valid['features'], valid['labels']
X_test_org, y_test_org = test['features'], test['labels']
```

---

## Step 1: Dataset Summary & Exploration

The pickled data is a dictionary with 4 key/value pairs:

- `'features'` is a 4D array containing raw pixel data of the traffic sign images, (num examples, width, height, channels).
- `'labels'` is a 1D array containing the label/class id of the traffic sign. The file `signnames.csv` contains id -> name mappings for each id.
- `'sizes'` is a list containing tuples, (width, height) representing the original width and height the image.
- `'coords'` is a list containing tuples, (x1, y1, x2, y2) representing coordinates of a bounding box around the sign in the image. **THESE COORDINATES ASSUME THE ORIGINAL IMAGE. THE PICKLED DATA CONTAINS RESIZED VERSIONS (32 by 32) OF THESE IMAGES**

Complete the basic data summary below. Use python, numpy and/or pandas methods to calculate the data summary rather than hard coding the results. For example, the [pandas shape method](http://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.shape.html) might be useful for calculating some of the summary results. 

### Provide a Basic Summary of the Data Set Using Python, Numpy and/or Pandas


```python
### Replace each question mark with the appropriate value. 
### Use python, pandas or numpy methods rather than hard coding the results

# Number of training examples
n_train = X_train_org.shape[0]

# Number of validation examples
n_validation = X_valid_org.shape[0]

# Number of testing examples.
n_test = X_test_org.shape[0]

# What's the shape of an traffic sign image?
image_shape = X_train_org.shape[1:3]

# How many unique classes/labels there are in the dataset.
n_classes = len(set(y_train_org))

print("Number of training examples =", n_train)
print("Number of testing examples =", n_test)
print("Image data shape =", image_shape)
print("Number of classes =", n_classes)
```

    Number of training examples = 34799
    Number of testing examples = 12630
    Image data shape = (32, 32)
    Number of classes = 43


### Include an exploratory visualization of the dataset

Visualize the German Traffic Signs Dataset using the pickled file(s). This is open ended, suggestions include: plotting traffic sign images, plotting the count of each sign, etc. 

The [Matplotlib](http://matplotlib.org/) [examples](http://matplotlib.org/examples/index.html) and [gallery](http://matplotlib.org/gallery.html) pages are a great resource for doing visualizations in Python.

**NOTE:** It's recommended you start with something simple first. If you wish to do more, come back to it after you've completed the rest of the sections. It can be interesting to look at the distribution of classes in the training, validation and test set. Is the distribution the same? Are there more examples of some classes than others?


```python
### Data exploration visualization code goes here.
### Feel free to use as many code cells as needed.
import matplotlib.pyplot as plt
# Visualizations will be shown in the notebook.
%matplotlib inline
```


```python
### Plot random train image and its label
image_nr = randint(0,n_train-1)
signnames = {}
with open('signnames.csv', newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        signnames[row['ClassId']] = row['SignName']

print(signnames[str(y_train_org[image_nr])])
plt.imshow(X_train_org[image_nr,:,:,:])
```

    Speed limit (20km/h)





    <matplotlib.image.AxesImage at 0x7f8ecdb95da0>




![png](output_11_2.png)



```python
### Plot count per label
plt.rcdefaults()
fig, ax = plt.subplots()

ax.hist(y_train_org, bins=n_classes)

ax.set_title('Number of pictures per label')
ax.set_ylabel("Amount")
ax.set_xlabel("Label as Number")

plt.show()
```


![png](output_12_0.png)


----

## Step 2: Design and Test a Model Architecture

Design and implement a deep learning model that learns to recognize traffic signs. Train and test your model on the [German Traffic Sign Dataset](http://benchmark.ini.rub.de/?section=gtsrb&subsection=dataset).

The LeNet-5 implementation shown in the [classroom](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) at the end of the CNN lesson is a solid starting point. You'll have to change the number of classes and possibly the preprocessing, but aside from that it's plug and play! 

With the LeNet-5 solution from the lecture, you should expect a validation set accuracy of about 0.89. To meet specifications, the validation set accuracy will need to be at least 0.93. It is possible to get an even higher accuracy, but 0.93 is the minimum for a successful project submission. 

There are various aspects to consider when thinking about this problem:

- Neural network architecture (is the network over or underfitting?)
- Play around preprocessing techniques (normalization, rgb to grayscale, etc)
- Number of examples per label (some have more than others).
- Generate fake data.

Here is an example of a [published baseline model on this problem](http://yann.lecun.com/exdb/publis/pdf/sermanet-ijcnn-11.pdf). It's not required to be familiar with the approach used in the paper but, it's good practice to try to read papers like these.

### Pre-process the Data Set (normalization, grayscale, etc.)

Minimally, the image data should be normalized so that the data has mean zero and equal variance. For image data, `(pixel - 128)/ 128` is a quick way to approximately normalize the data and can be used in this project. 

Other pre-processing steps are optional. You can try different techniques to see if it improves performance. 

Use the code cell (or multiple code cells, if necessary) to implement the first step of your project.


```python
### Preprocess the data here.

### Grayscale
def bgr2grayscale(image_data):
    image_data_new = image_data[:,:,:,0].copy()
    for i in range(0,image_data.shape[0]):
        image_data_new[i] = (cv2.cvtColor(image_data[i], cv2.COLOR_BGR2GRAY))
    image_data_new = image_data_new[:,:,:,np.newaxis]
    return image_data_new

### YUV colorspace
def bgr2yuv(image_data):
    image_data_new = image_data.copy()
    for i in range(0,image_data.shape[0]):
        image_data_new[i] = (cv2.cvtColor(image_data[i], cv2.COLOR_BGR2YUV))
    return image_data_new

def yuv2grayscale(image_data):
    image_data_new = image_data[:,:,:,0].copy()
    image_data_new = image_data_new[:,:,:,np.newaxis]
    return image_data_new

### Normalize data
def normalize(image_data, image_min_new=-1, image_max_new=1):
    image_min = np.min(image_data)
    image_max = np.max(image_data)
    image_data_new = (image_data - image_min) * (image_max_new - image_min_new)/(image_max - image_min)  + image_min_new
    return image_data_new

### Standardization
def standardization(image_data, image_mean_arg=None, image_std_arg=None):
    if image_mean_arg is None or image_std_arg is None:
        global image_mean 
        image_mean = np.mean(image_data, 0)
        global image_std
        image_std = np.std(image_data, 0)
    
        # Save image mean and std
        image_mean_file = "data/image_mean.p"
        image_std_file = "data/image_std.p"
        with open(image_mean_file, mode='wb') as f:
            pickle.dump(image_mean, f)
        with open(image_std_file, mode='wb') as f:
            pickle.dump(image_std, f)
    else:
        image_mean = image_mean_arg
        image_std = image_std_arg
    image_data_new = (image_data-image_mean)/image_std
    return image_data_new

def preprocess(image_data_train, image_data_valid, image_data_test, do_grayscale=DO_GRAYSCALE,
               do_normalize=DO_NORMALIZE, do_standardization=DO_STANDARDIZATION, do_bgr2yuv=DO_BGR2YUV,
              do_yuv2grayscale=DO_YUV2GRAYSCALE):
    image_data_preprocess_train = image_data_train
    image_data_preprocess_valid = image_data_valid
    image_data_preprocess_test = image_data_test
    if do_grayscale:
        image_data_preprocess_train = grayscale(image_data_preprocess_train)
        image_data_preprocess_valid = grayscale(image_data_preprocess_valid)
        image_data_preprocess_test = grayscale(image_data_preprocess_test)
    if do_bgr2yuv:
        image_data_preprocess_train = bgr2yuv(image_data_preprocess_train)
        image_data_preprocess_valid = bgr2yuv(image_data_preprocess_valid)
        image_data_preprocess_test = bgr2yuv(image_data_preprocess_test)
    if do_yuv2grayscale:
        image_data_preprocess_train = yuv2grayscale(image_data_preprocess_train)
        image_data_preprocess_valid = yuv2grayscale(image_data_preprocess_valid)
        image_data_preprocess_test = yuv2grayscale(image_data_preprocess_test)
    if do_normalize:
        image_data_preprocess_train = normalize(image_data_preprocess_train)
        image_data_preprocess_valid = normalize(image_data_preprocess_valid)
        image_data_preprocess_test = normalize(image_data_preprocess_test)
    if do_standardization:
        image_data_preprocess_train = standardization(image_data_preprocess_train)
        image_data_preprocess_valid = standardization(image_data_preprocess_valid, image_mean_arg=image_mean, image_std_arg=image_std)
        image_data_preprocess_test = standardization(image_data_preprocess_test, image_mean_arg=image_mean, image_std_arg=image_std)
        
    return image_data_preprocess_train, image_data_preprocess_valid, image_data_preprocess_test
```


```python
### Image augmentation
def crop(image_data, image_label, crop_size=26):
    image_data_new = image_data[:,:,:].copy()
    count, h, w = image_data.shape[0], image_data.shape[1], image_data.shape[2]
    
    for i in range(0,count):
        crop_up = randint(0,w-crop_size-1)
        crop_left = randint(0,w-crop_size-1)
        image_data_new[i] = cv2.resize(image_data[i,crop_up:crop_up+crop_size,crop_left:crop_left+crop_size],(w,h))
    return image_data_new, image_label

def rotate(image_data, image_label, min_deg=-15, max_deg=15):
    image_data_new = image_data[:,:,:].copy()
    count, h, w = image_data.shape[0], image_data.shape[1], image_data.shape[2]
    
    for i in range(0,count):
        deg = randint(min_deg,max_deg)
        M = cv2.getRotationMatrix2D((h/2,w/2),deg,1)
        image_data_new[i] = cv2.warpAffine(image_data_new[i],M,(h,w))
    return image_data_new, image_label

def pad(image_data, image_label, min_pad=-8, max_pad=8):
    image_data_new = image_data[:,:,:].copy()
    count, h, w = image_data.shape[0], image_data.shape[1], image_data.shape[2]
    
    for i in range(0,count):
        pad_h = randint(min_pad,max_pad)
        pad_w = randint(min_pad,max_pad)
        M = np.float32([[1,0,pad_h],[0,1,pad_w]])
        image_data_new[i] = cv2.warpAffine(image_data_new[i],M,(h,w))
    return image_data_new, image_label

def change_brightness(image_data, image_label):
    image_data_new = image_data[:,:,:].copy()
    count, h, w = image_data.shape[0], image_data.shape[1], image_data.shape[2]
    
    for i in range(0,count):        
        i_hsv = cv2.cvtColor(image_data_new[i], cv2.COLOR_BGR2HSV)
        i_hsv_max = np.max(i_hsv[:,:,2])
        i_hsv_min = np.min(i_hsv[:,:,2])
        
        i_hsv[:,:,2] += np.uint8(randint(0,(255-i_hsv_max)//2+(i_hsv_min//2))-(i_hsv_min//2))
        image_data_new[i] = cv2.cvtColor(i_hsv, cv2.COLOR_HSV2BGR)
    return image_data_new, image_label

def image_augmentation(image_data, image_label, do_change_brightness=DO_CHANGE_BRIGHTNESS, do_crop=DO_CROP,
                       do_rotate=DO_ROTATE, do_pad=DO_PAD):
    
    image_data_new = image_data.copy()
    image_label_new = image_label.copy()
    if do_change_brightness:
        cb = change_brightness(image_data,image_label)
        image_data_new = np.concatenate((image_data_new,cb[0]), axis=0)
        image_label_new = np.concatenate((image_label_new,cb[1]), axis=0)
        
    if do_crop:
        croped = crop(image_data,image_label)
        image_data = np.concatenate((image_data_new,croped[0]), axis=0)
        image_label = np.concatenate((image_label_new,croped[1]), axis=0)
        
    if do_rotate:
        rotated = rotate(image_data,image_label)
        image_data = np.concatenate((image_data_new,rotated[0]), axis=0)
        image_label = np.concatenate((image_label_new,rotated[1]), axis=0)
        
    if do_pad:
        paded = pad(image_data,image_label)
        image_data = np.concatenate((image_data_new,paded[0]), axis=0)
        image_label = np.concatenate((image_label_new,paded[1]), axis=0)
        
    return image_data,image_label
```


```python
X_train, y_train = image_augmentation(X_train_org, y_train_org)
X_train, X_valid, X_test = preprocess(X_train, X_valid_org, X_test_org)

y_test = y_test_org
y_valid = y_valid_org

validation_file_prep = "data/valid_prep.p"
testing_file_prep = "data/test_prep.p"
image_mean_file = "data/image_mean.p"
image_std_file = "data/image_std.p"

with open(validation_file_prep, mode='wb') as f:
    pickle.dump(X_valid, f)
with open(testing_file_prep, mode='wb') as f:
    pickle.dump(X_test, f)
    

with open(image_mean_file, mode='rb') as f:
    image_mean = pickle.load(f)
with open(image_std_file, mode='rb') as f:
    image_std = pickle.load(f)
    
print("Number of training examples after image augmentation=", X_train.shape[0])
```

    Number of training examples after image augmentation= 243593


### Model Architecture


```python
### Define the architecture here.

from tensorflow.contrib.layers import flatten
import tensorflow as tf

def TrafficSignNet(x):
    # Arguments used for tf.truncated_normal, randomly defines variables for the weights and biases for each layer
    mu = 0
    sigma = 0.1
    
    # Def Input dim for color or grayscale
    if DO_GRAYSCALE or DO_YUV2GRAYSCALE:
        input_dim =  1
    else:
        input_dim =  3
    
    # Layer 1: Convolutional. Output = 32x32x8.
    conv1_W = tf.Variable(tf.truncated_normal(shape=(5, 5, input_dim, 8), mean = mu, stddev = sigma))
    conv1_b = tf.Variable(tf.zeros(8))
    conv1   = tf.nn.conv2d(x, conv1_W, strides=[1, 1, 1, 1], padding='SAME') + conv1_b
    conv1 = tf.nn.relu(conv1)

    # Layer 2: Convolutional. Output = 32x32x8.
    conv2_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 8, 8), mean = mu, stddev = sigma))
    conv2_b = tf.Variable(tf.zeros(8))
    conv2   = tf.nn.conv2d(conv1, conv2_W, strides=[1, 1, 1, 1], padding='SAME') + conv2_b
    conv2 = tf.nn.relu(conv2)
    conv2 = tf.nn.dropout(conv2, keep_prob)

    # Layer 3: Convolutional. Output = 16x16x16.
    conv3_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 8, 16), mean = mu, stddev = sigma))
    conv3_b = tf.Variable(tf.zeros(16))
    conv3   = tf.nn.conv2d(conv2, conv3_W, strides=[1, 2, 2, 1], padding='SAME') + conv3_b
    conv3 = tf.nn.relu(conv3)
    
    # Layer 4: Convolutional. Output = 16x16x16.
    conv4_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 16, 16), mean = mu, stddev = sigma))
    conv4_b = tf.Variable(tf.zeros(16))
    conv4   = tf.nn.conv2d(conv3, conv4_W, strides=[1, 1, 1, 1], padding='SAME') + conv4_b
    conv4 = tf.nn.relu(conv4)
    conv4 = tf.nn.dropout(conv4, keep_prob)
    
    # Layer 5: Convolutional. Output = 8x8x32.
    conv5_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 16, 32), mean = mu, stddev = sigma))
    conv5_b = tf.Variable(tf.zeros(32))
    conv5   = tf.nn.conv2d(conv4, conv5_W, strides=[1, 2, 2, 1], padding='SAME') + conv5_b
    conv5 = tf.nn.relu(conv5)
    
    # Layer 6: Convolutional. Output = 8x8x32.
    conv6_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 32, 32), mean = mu, stddev = sigma))
    conv6_b = tf.Variable(tf.zeros(32))
    conv6   = tf.nn.conv2d(conv5, conv6_W, strides=[1, 1, 1, 1], padding='SAME') + conv6_b
    conv6 = tf.nn.relu(conv6)
    
    # Layer 7: Convolutional. Output = 8x8x32.
    conv7_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 32, 32), mean = mu, stddev = sigma))
    conv7_b = tf.Variable(tf.zeros(32))
    conv7   = tf.nn.conv2d(conv6, conv7_W, strides=[1, 1, 1, 1], padding='SAME') + conv7_b
    conv7 = tf.nn.relu(conv7)
    
    # Layer 8: Convolutional. Output = 8x8x32.
    conv8_W = tf.Variable(tf.truncated_normal(shape=(3, 3, 32, 32), mean = mu, stddev = sigma))
    conv8_b = tf.Variable(tf.zeros(32))
    conv8   = tf.nn.conv2d(conv7, conv8_W, strides=[1, 1, 1, 1], padding='SAME') + conv8_b
    conv8 = tf.nn.relu(conv8)
    conv8 = tf.nn.dropout(conv8, keep_prob)
    
    # Flatten Input = 8x8x64. Output = 2048.
    fc0   = flatten(conv8)
    
    # Layer 9: Fully Connected. Input = 2048. Output = 43.
    fc1_W = tf.Variable(tf.truncated_normal(shape=(2048, 43), mean = mu, stddev = sigma))
    fc1_b = tf.Variable(tf.zeros(43))
    logits   = tf.matmul(fc0, fc1_W) + fc1_b
    
    return logits
```

### Train, Validate and Test the Model

A validation set can be used to assess how well the model is performing. A low accuracy on the training and validation
sets imply underfitting. A high accuracy on the training set but low accuracy on the validation set implies overfitting.


```python
### Train the model here.
from sklearn.utils import shuffle

tf.reset_default_graph()

if DO_GRAYSCALE or DO_YUV2GRAYSCALE:
    x = tf.placeholder(tf.float32, (None, 32, 32, 1))
else:
    x = tf.placeholder(tf.float32, (None, 32, 32, 3))
    
y = tf.placeholder(tf.int32, (None))
one_hot_y = tf.one_hot(y, 43)

keep_prob = tf.placeholder(tf.float32)
rate = 0.001

logits = TrafficSignNet(x)

cross_entropy = tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_y, logits=logits)
loss_operation = tf.reduce_mean(cross_entropy)
optimizer = tf.train.AdamOptimizer(learning_rate = rate)
training_operation = optimizer.minimize(loss_operation)

correct_prediction = tf.equal(tf.argmax(logits, 1), tf.argmax(one_hot_y, 1))
accuracy_operation = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
saver = tf.train.Saver()

def evaluate(X_data, y_data):
    num_examples = len(X_data)
    total_accuracy = 0
    sess = tf.get_default_session()
    for offset in range(0, num_examples, BATCH_SIZE):
        batch_x, batch_y = X_data[offset:offset+BATCH_SIZE], y_data[offset:offset+BATCH_SIZE]
        accuracy = sess.run(accuracy_operation, feed_dict={x: batch_x, y: batch_y, keep_prob: 1})
        total_accuracy += (accuracy * len(batch_x))
    return total_accuracy / num_examples

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())       
    num_examples = len(X_train)
    
    print("Training...")
    print()
    for i in range(EPOCHS):
        X_train, y_train = shuffle(X_train, y_train)
        for offset in range(0, num_examples, BATCH_SIZE):
            end = offset + BATCH_SIZE
            batch_x, batch_y = X_train[offset:end], y_train[offset:end]
            sess.run(training_operation, feed_dict={x: batch_x, y: batch_y, keep_prob: 0.5})
            
        validation_accuracy = evaluate(X_valid, y_valid)
        print("EPOCH {} ...".format(i+1))
        print("Validation Accuracy = {:.3f}".format(validation_accuracy))
        print()
        
    saver.save(sess, './trafficSignNet')
    print("Model saved")
```

    Training...
    
    EPOCH 1 ...
    Validation Accuracy = 0.610
    
    EPOCH 2 ...
    Validation Accuracy = 0.756
    
    EPOCH 3 ...
    Validation Accuracy = 0.825
    
    EPOCH 4 ...
    Validation Accuracy = 0.871
    
    EPOCH 5 ...
    Validation Accuracy = 0.883
    
    EPOCH 6 ...
    Validation Accuracy = 0.911
    
    EPOCH 7 ...
    Validation Accuracy = 0.927
    
    EPOCH 8 ...
    Validation Accuracy = 0.927
    
    EPOCH 9 ...
    Validation Accuracy = 0.940
    
    EPOCH 10 ...
    Validation Accuracy = 0.941
    
    EPOCH 11 ...
    Validation Accuracy = 0.954
    
    EPOCH 12 ...
    Validation Accuracy = 0.954
    
    EPOCH 13 ...
    Validation Accuracy = 0.959
    
    EPOCH 14 ...
    Validation Accuracy = 0.967
    
    EPOCH 15 ...
    Validation Accuracy = 0.968
    
    EPOCH 16 ...
    Validation Accuracy = 0.970
    
    EPOCH 17 ...
    Validation Accuracy = 0.975
    
    EPOCH 18 ...
    Validation Accuracy = 0.970
    
    EPOCH 19 ...
    Validation Accuracy = 0.969
    
    EPOCH 20 ...
    Validation Accuracy = 0.971
    
    EPOCH 21 ...
    Validation Accuracy = 0.973
    
    EPOCH 22 ...
    Validation Accuracy = 0.967
    
    EPOCH 23 ...
    Validation Accuracy = 0.977
    
    EPOCH 24 ...
    Validation Accuracy = 0.969
    
    EPOCH 25 ...
    Validation Accuracy = 0.976
    
    EPOCH 26 ...
    Validation Accuracy = 0.973
    
    EPOCH 27 ...
    Validation Accuracy = 0.977
    
    EPOCH 28 ...
    Validation Accuracy = 0.973
    
    EPOCH 29 ...
    Validation Accuracy = 0.981
    
    EPOCH 30 ...
    Validation Accuracy = 0.972
    
    Model saved



```python
### Test Accuracy
with tf.Session() as sess:
    # Load the weights and bias
    saver.restore(sess, './trafficSignNet')

    test_accuracy = evaluate(X_test, y_test)
    print("Test Accuracy = {:.3f}".format(test_accuracy))
    print()
```

    Test Accuracy = 0.964
    


---

## Step 3: Test a Model on New Images

To give yourself more insight into how your model is working, download at least five pictures of German traffic signs from the web and use your model to predict the traffic sign type.

You may find `signnames.csv` useful as it contains mappings from the class id (integer) to the actual sign name.

### Load and Output the Images


```python
### Load the images and plot them here.
### Feel free to use as many code cells as needed.

signs = np.zeros((5,32,32,4))
signs[0] = cv2.resize(mpimg.imread('data/sign1.png'), (32,32))*255
signs[1] = cv2.resize(mpimg.imread('data/sign2.png'), (32,32))*255
signs[2] = cv2.resize(mpimg.imread('data/sign3.png'), (32,32))*255
signs[3] = cv2.resize(mpimg.imread('data/sign4.png'), (32,32))*255
signs[4] = cv2.resize(mpimg.imread('data/sign5.png'), (32,32))*255
signs = signs[:,:,:,:3].astype(np.uint8)

labels = np.zeros((5,43))
labels[0,11] = 1
labels[1,13] = 1
labels[2,13] = 1
labels[3,38] = 1
labels[4,14] = 1

plt.subplot(151)
plt.imshow(signs[0])
plt.subplot(152)
plt.imshow(signs[1])
plt.subplot(153)
plt.imshow(signs[2])
plt.subplot(154)
plt.imshow(signs[3])
plt.subplot(155)
plt.imshow(signs[4])
```




    <matplotlib.image.AxesImage at 0x7f8e8a633208>




![png](output_27_1.png)


### Predict the Sign Type for Each Image


```python
### Run the predictions here and use the model to output the prediction for each image.
### Make sure to pre-process the images with the same pre-processing pipeline used earlier.
### Feel free to use as many code cells as needed.
signs_prep = standardization(yuv2grayscale(bgr2yuv(signs)), image_mean, image_std)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    sess = tf.get_default_session()
    saver.restore(sess, './trafficSignNet')
    classifys = sess.run(tf.nn.softmax(logits=logits), feed_dict={x: signs_prep, keep_prob: 1})
    for idx, val in enumerate(np.argmax(classifys, axis=1)):
        print("Sign "+str(idx+1)+": "+signnames[str(val)])
```

    Sign 1: Right-of-way at the next intersection
    Sign 2: Yield
    Sign 3: Yield
    Sign 4: Keep right
    Sign 5: Stop


### Analyze Performance


```python
### Calculate the accuracy for these 5 new images. 
### For example, if the model predicted 1 out of 5 signs correctly, it's 20% accurate on these new images.
correct_prediction = tf.equal(tf.argmax(classifys, 1), tf.argmax(labels, 1))
accuracy_operation = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
with tf.Session() as sess:
    accuracy = sess.run(accuracy_operation)
    print("Accuracy = {:.3f}".format(accuracy))
```

    Accuracy = 1.000


### Output Top 5 Softmax Probabilities For Each Image Found on the Web

For each of the new images, print out the model's softmax probabilities to show the **certainty** of the model's predictions (limit the output to the top 5 probabilities for each image). [`tf.nn.top_k`](https://www.tensorflow.org/versions/r0.12/api_docs/python/nn.html#top_k) could prove helpful here. 

The example below demonstrates how tf.nn.top_k can be used to find the top k predictions for each image.

`tf.nn.top_k` will return the values and indices (class ids) of the top k predictions. So if k=3, for each sign, it'll return the 3 largest probabilities (out of a possible 43) and the correspoding class ids.

Take this numpy array as an example. The values in the array represent predictions. The array contains softmax probabilities for five candidate images with six possible classes. `tf.nn.top_k` is used to choose the three classes with the highest probability:

```
# (5, 6) array
a = np.array([[ 0.24879643,  0.07032244,  0.12641572,  0.34763842,  0.07893497,
         0.12789202],
       [ 0.28086119,  0.27569815,  0.08594638,  0.0178669 ,  0.18063401,
         0.15899337],
       [ 0.26076848,  0.23664738,  0.08020603,  0.07001922,  0.1134371 ,
         0.23892179],
       [ 0.11943333,  0.29198961,  0.02605103,  0.26234032,  0.1351348 ,
         0.16505091],
       [ 0.09561176,  0.34396535,  0.0643941 ,  0.16240774,  0.24206137,
         0.09155967]])
```

Running it through `sess.run(tf.nn.top_k(tf.constant(a), k=3))` produces:

```
TopKV2(values=array([[ 0.34763842,  0.24879643,  0.12789202],
       [ 0.28086119,  0.27569815,  0.18063401],
       [ 0.26076848,  0.23892179,  0.23664738],
       [ 0.29198961,  0.26234032,  0.16505091],
       [ 0.34396535,  0.24206137,  0.16240774]]), indices=array([[3, 0, 5],
       [0, 1, 4],
       [0, 5, 1],
       [1, 3, 5],
       [1, 4, 3]], dtype=int32))
```

Looking just at the first row we get `[ 0.34763842,  0.24879643,  0.12789202]`, you can confirm these are the 3 largest probabilities in `a`. You'll also notice `[3, 0, 5]` are the corresponding indices.


```python
### Print out the top five softmax probabilities for the predictions on the German traffic sign images found on the web. 
### Feel free to use as many code cells as needed.
with tf.Session() as sess:
    top_k = sess.run(tf.nn.top_k(classifys, k=5))
    print(top_k)
```

    TopKV2(values=array([[  9.99990225e-01,   9.75883540e-06,   4.01302713e-10,
              3.87124111e-10,   6.02728631e-11],
           [  1.00000000e+00,   1.67233491e-12,   1.93246755e-16,
              8.39130659e-17,   3.30612510e-17],
           [  1.00000000e+00,   3.14076349e-16,   4.84349089e-17,
              6.26238861e-20,   6.10759727e-20],
           [  1.00000000e+00,   4.25718389e-16,   8.84882147e-19,
              2.64888915e-22,   2.53817751e-22],
           [  1.00000000e+00,   5.07510300e-09,   8.55824023e-11,
              5.10979314e-11,   3.73267632e-11]], dtype=float32), indices=array([[11, 30, 28, 27, 21],
           [13, 12, 30,  9, 11],
           [13, 12,  9, 15, 41],
           [38, 12, 34,  1, 21],
           [14, 40,  2, 34,  3]], dtype=int32))


### Project Writeup

Once you have completed the code implementation, document your results in a project writeup using this [template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) as a guide. The writeup can be in a markdown or pdf file. 

> **Note**: Once you have completed all of the code implementations and successfully answered each question above, you may finalize your work by exporting the iPython Notebook as an HTML document. You can do this by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission.

---

## Step 4 (Optional): Visualize the Neural Network's State with Test Images

 This Section is not required to complete but acts as an additional excersise for understaning the output of a neural network's weights. While neural networks can be a great learning device they are often referred to as a black box. We can understand what the weights of a neural network look like better by plotting their feature maps. After successfully training your neural network you can see what it's feature maps look like by plotting the output of the network's weight layers in response to a test stimuli image. From these plotted feature maps, it's possible to see what characteristics of an image the network finds interesting. For a sign, maybe the inner network feature maps react with high activation to the sign's boundary outline or to the contrast in the sign's painted symbol.

 Provided for you below is the function code that allows you to get the visualization output of any tensorflow weight layer you want. The inputs to the function should be a stimuli image, one used during training or a new one you provided, and then the tensorflow variable name that represents the layer's state during the training process, for instance if you wanted to see what the [LeNet lab's](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) feature maps looked like for it's second convolutional layer you could enter conv2 as the tf_activation variable.

For an example of what feature map outputs look like, check out NVIDIA's results in their paper [End-to-End Deep Learning for Self-Driving Cars](https://devblogs.nvidia.com/parallelforall/deep-learning-self-driving-cars/) in the section Visualization of internal CNN State. NVIDIA was able to show that their network's inner weights had high activations to road boundary lines by comparing feature maps from an image with a clear path to one without. Try experimenting with a similar test to show that your trained network's weights are looking for interesting features, whether it's looking at differences in feature maps from images with or without a sign, or even what feature maps look like in a trained network vs a completely untrained one on the same sign image.

<figure>
 <img src="visualize_cnn.png" width="380" alt="Combined Image" />
 <figcaption>
 <p></p> 
 <p style="text-align: center;"> Your output should look something like this (above)</p> 
 </figcaption>
</figure>
 <p></p> 



```python
### Visualize your network's feature maps here.
### Feel free to use as many code cells as needed.

# image_input: the test image being fed into the network to produce the feature maps
# tf_activation: should be a tf variable name used during your training procedure that represents the calculated state of a specific weight layer
# activation_min/max: can be used to view the activation contrast in more detail, by default matplot sets min and max to the actual min and max values of the output
# plt_num: used to plot out multiple different weight feature map sets on the same block, just extend the plt number for each new feature map entry

def outputFeatureMap(image_input, tf_activation, activation_min=-1, activation_max=-1 ,plt_num=1):
    # Here make sure to preprocess your image_input in a way your network expects
    # with size, normalization, ect if needed
    # image_input =
    # Note: x should be the same name as your network's tensorflow data placeholder variable
    # If you get an error tf_activation is not defined it may be having trouble accessing the variable from inside a function
    activation = tf_activation.eval(session=sess,feed_dict={x : image_input, keep_prob: 1})
    featuremaps = activation.shape[3]
    plt.figure(plt_num, figsize=(15,15))
    for featuremap in range(featuremaps):
        plt.subplot(6,8, featuremap+1) # sets the number of feature maps to show on each row and column
        plt.title('FeatureMap ' + str(featuremap)) # displays the feature map number
        if activation_min != -1 & activation_max != -1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmin =activation_min, vmax=activation_max, cmap="gray")
        elif activation_max != -1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmax=activation_max, cmap="gray")
        elif activation_min !=-1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmin=activation_min, cmap="gray")
        else:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", cmap="gray")
```


```python
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    sess = tf.get_default_session()
    saver.restore(sess, './trafficSignNet')
        
    tensor = tf.get_default_graph().get_tensor_by_name("Relu:0")
    print(tensor)
    image = signs_prep[1]
    image = image[np.newaxis,:,:,:]
    outputFeatureMap(image, tensor)    
```

    Tensor("Relu:0", shape=(?, 32, 32, 8), dtype=float32)



![png](output_39_1.png)

